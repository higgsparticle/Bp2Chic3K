#define MCDecayTree_cxx
#define DTDecayTree_cxx
#include "/home/wangzh/workdir/B2chicPhiK/tuples/MCDecayTree.h"
#include "/home/wangzh/workdir/B2chicPhiK/tuples/DTDecayTree.h"

void cut() {

   //gROOT->ProcessLine(".L /home/wangzh/workdir/pictures/lhcbstyle.C");
   //lhcbStyle();

   TChain* MCChain = new TChain("TUPLE/DecayTree");
   TChain* DTChain = new TChain("TUPLE/DecayTree");

   MCChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MC2011.root");
   MCChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MC2012.root");
   DTChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MU2011.root");
   DTChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MU2012.root");
   DTChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MD2011.root");
   DTChain->Add("/home/wangzh/workdir/B2chicPhiK/tuples/MD2012.root");

   TH1F* MCh = new TH1F ("MCh", "Bp_M-chi_c_M+3510", 400, 4910, 6310);
   TH1F* DTh = new TH1F ("DTh", "Bp_M-chi_c_M+3510", 400, 4910, 6310);
   //cut candidates
   TH1F* h1m = new TH1F ("h1m", "Bp_ENDVERTEX_CHI2", 400, 0, 70);
   TH1F* h1d = new TH1F ("h1d", "Bp_ENDVERTEX_CHI2", 400, 0, 70);

   TH1F* h2m = new TH1F ("h2m", "Bp_IPCHI2_OWNPV", 400, 0, 280);
   TH1F* h2d = new TH1F ("h2d", "Bp_IPCHI2_OWNPV", 400, 0, 280);

   TH1F* h3m = new TH1F ("h3m", "Bp_FDS", 400, 0, 300);
   TH1F* h3d = new TH1F ("h3d", "Bp_FDS", 400, 0, 300);

   TH1F* h4m = new TH1F ("h4m", "Bp_DIRA", 400, 0.999, 1);
   TH1F* h4d = new TH1F ("h4d", "Bp_DIRA", 400, 0.999, 1);

   TH1F* h5m = new TH1F ("h5m", "gamma_CL", 400, 0, 1);
   TH1F* h5d = new TH1F ("h5d", "gamma_CL", 400, 0, 1);

   TH1F* h6m = new TH1F ("h6m", "muplus_IPCHI2_OWNPV", 400, 0, 2000);
   TH1F* h6d = new TH1F ("h6d", "muplus_IPCHI2_OWNPV", 400, 0, 2000);

   TH1F* h7m = new TH1F ("h7m", "muminus_IPCHI2_OWNPV", 400, 0, 10000);
   TH1F* h7d = new TH1F ("h7d", "muminus_IPCHI2_OWNPV", 400, 0, 10000);

   TH1F* h8m = new TH1F ("h8m", "Jpsi_ENDVERTEX_CHI2", 400, 0, 20);
   TH1F* h8d = new TH1F ("h8d", "Jpsi_ENDVERTEX_CHI2", 400, 0, 20);

   TH1F* h9m = new TH1F ("h9m", "muplus_ProbNNghost", 400, 0, 0.4 );
   TH1F* h9d = new TH1F ("h9d", "muplus_ProbNNghost", 400, 0, 0.4 );

   TH1F* h10m = new TH1F ("h10m", "muminus_ProbNNghost", 400, 0, 0.4 );
   TH1F* h10d = new TH1F ("h10d", "muminus_ProbNNghost", 400, 0, 0.4 );

   TH1F* h11m = new TH1F ("h11m", "muplus_ProbNNmu", 400, 0, 1 );
   TH1F* h11d = new TH1F ("h11d", "muplus_ProbNNmu", 400, 0, 1 );

   TH1F* h12m = new TH1F ("h12m", "muminus_ProbNNmu", 400, 0, 1 );
   TH1F* h12d = new TH1F ("h12d", "muminus_ProbNNmu", 400, 0, 1 );

   TH1F* h13m = new TH1F ("h13m", "muplus_PT", 400, 0, 15000 );
   TH1F* h13d = new TH1F ("h13d", "muplus_PT", 400, 0, 15000 );

   TH1F* h14m = new TH1F ("h14m", "muminus_PT", 400, 0, 15000 );
   TH1F* h14d = new TH1F ("h14d", "muminus_PT", 400, 0, 15000 );

   TH1F* h15m = new TH1F ("h15m", "kaonp1_P", 400, 0, 100000 );
   TH1F* h15d = new TH1F ("h15d", "kaonp1_P", 400, 0, 100000 );

   TH1F* h16m = new TH1F ("h16m", "kaonp2_P", 400, 0, 100000 );
   TH1F* h16d = new TH1F ("h16d", "kaonp2_P", 400, 0, 100000 );

   TH1F* h17m = new TH1F ("h17m", "kaonm_P", 400, 0, 100000 );
   TH1F* h17d = new TH1F ("h17d", "kaonm_P", 400, 0, 100000 );

   TH1F* h18m = new TH1F ("h18m", "kaonp1_PT", 400, 0, 6000 );
   TH1F* h18d = new TH1F ("h18d", "kaonp1_PT", 400, 0, 6000 );

   TH1F* h19m = new TH1F ("h19m", "kaonp2_PT", 400, 0, 6000 );
   TH1F* h19d = new TH1F ("h19d", "kaonp2_PT", 400, 0, 6000 );

   TH1F* h20m = new TH1F ("h20m", "kaonm_PT", 400, 0, 6000 );
   TH1F* h20d = new TH1F ("h20d", "kaonm_PT", 400, 0, 6000 );

   TH1F* h21m = new TH1F ("h21m", "kaonp1_IPCHI2_OWNPV", 400, 0, 500 );
   TH1F* h21d = new TH1F ("h21d", "kaonp1_IPCHI2_OWNPV", 400, 0, 5000 );

   TH1F* h22m = new TH1F ("h22m", "kaonp2_IPCHI2_OWNPV", 400, 0, 500 );
   TH1F* h22d = new TH1F ("h22d", "kaonp2_IPCHI2_OWNPV", 400, 0, 500 );

   TH1F* h23m = new TH1F ("h23m", "kaonm_IPCHI2_OWNPV", 400, 0, 500 );
   TH1F* h23d = new TH1F ("h23d", "kaonm_IPCHI2_OWNPV", 400, 0, 500 );

   TH1F* h24m = new TH1F ("h24m", "kaonp1_TRACK_CHI2NDOF", 400, 0, 3 );
   TH1F* h24d = new TH1F ("h24d", "kaonp1_TRACK_CHI2NDOF", 400, 0, 3 );

   TH1F* h25m = new TH1F ("h25m", "kaonp2_TRACK_CHI2NDOF", 400, 0, 3 );
   TH1F* h25d = new TH1F ("h25d", "kaonp2_TRACK_CHI2NDOF", 400, 0, 3 );

   TH1F* h26m = new TH1F ("h26m", "kaonm_TRACK_CHI2NDOF", 400, 0, 3 );
   TH1F* h26d = new TH1F ("h26d", "kaonm_TRACK_CHI2NDOF", 400, 0, 3 );

   TH1F* h27m = new TH1F ("h27m", "kaonp1_hasRich", 400, 0, 3 );
   TH1F* h27d = new TH1F ("h27d", "kaonp1_hasRich", 400, 0, 3 );

   TH1F* h28m = new TH1F ("h28m", "kaonp2_hasRich", 400, 0, 3 );
   TH1F* h28d = new TH1F ("h28d", "kaonp2_hasRich", 400, 0, 3 );

   TH1F* h29m = new TH1F ("h29m", "kaonm_hasRich", 400, 0, 3 );
   TH1F* h29d = new TH1F ("h29d", "kaonm_hasRich", 400, 0, 3 );

   TH1F* h30m = new TH1F ("h30m", "kaonp1_TRACK_GhostProb", 400, 0, 0.5 );
   TH1F* h30d = new TH1F ("h30d", "kaonp1_TRACK_GhostProb", 400, 0, 0.5 );

   TH1F* h31m = new TH1F ("h31m", "kaonp2_TRACK_GhostProb", 400, 0, 0.5 );
   TH1F* h31d = new TH1F ("h31d", "kaonp2_TRACK_GhostProb", 400, 0, 0.5 );

   TH1F* h32m = new TH1F ("h32m", "kaonm_TRACK_GhostProb", 400, 0, 0.5 );
   TH1F* h32d = new TH1F ("h32d", "kaonm_TRACK_GhostProb", 400, 0, 0.5 );

   TH1F* h33m = new TH1F ("h33m", "kaonp1_ProbNNk", 400, 0, 1 );
   TH1F* h33d = new TH1F ("h33d", "kaonp1_ProbNNk", 400, 0, 1 );

   //creating canvas
   TCanvas *C0 = new TCanvas("C0","A Canvas",10,10,800,600);
   TCanvas *C1 = new TCanvas("C1","A Canvas",10,10,800,600);
   TCanvas *C2 = new TCanvas("C2","A Canvas",10,10,800,600);
   TCanvas *C3 = new TCanvas("C3","A Canvas",10,10,800,600);
   TCanvas *C4 = new TCanvas("C4","A Canvas",10,10,800,600);
   TCanvas *C5 = new TCanvas("C5","A Canvas",10,10,800,600);
   TCanvas *C6 = new TCanvas("C6","A Canvas",10,10,800,600);
   TCanvas *C7 = new TCanvas("C7","A Canvas",10,10,800,600);
   TCanvas *C8 = new TCanvas("C8","A Canvas",10,10,800,600);
   TCanvas *C9 = new TCanvas("C9","A Canvas",10,10,800,600);
   TCanvas *C10 = new TCanvas("C10","A Canvas",10,10,800,600);
   TCanvas *C11 = new TCanvas("C11","A Canvas",10,10,800,600);
   TCanvas *C12 = new TCanvas("C12","A Canvas",10,10,800,600);
   TCanvas *C13 = new TCanvas("C13","A Canvas",10,10,800,600);
   TCanvas *C14 = new TCanvas("C14","A Canvas",10,10,800,600);
   TCanvas *C15 = new TCanvas("C15","A Canvas",10,10,800,600);
   TCanvas *C16 = new TCanvas("C16","A Canvas",10,10,800,600);
   TCanvas *C17 = new TCanvas("C17","A Canvas",10,10,800,600);
   TCanvas *C18 = new TCanvas("C18","A Canvas",10,10,800,600);
   TCanvas *C19 = new TCanvas("C19","A Canvas",10,10,800,600);
   TCanvas *C20 = new TCanvas("C20","A Canvas",10,10,800,600);
   TCanvas *C21 = new TCanvas("C21","A Canvas",10,10,800,600);
   TCanvas *C22 = new TCanvas("C22","A Canvas",10,10,800,600);
   TCanvas *C23 = new TCanvas("C23","A Canvas",10,10,800,600);
   TCanvas *C24 = new TCanvas("C24","A Canvas",10,10,800,600);
   TCanvas *C25 = new TCanvas("C25","A Canvas",10,10,800,600);
   TCanvas *C26 = new TCanvas("C26","A Canvas",10,10,800,600);
   TCanvas *C27 = new TCanvas("C27","A Canvas",10,10,800,600);
   TCanvas *C28 = new TCanvas("C28","A Canvas",10,10,800,600);
   TCanvas *C29 = new TCanvas("C29","A Canvas",10,10,800,600);
   TCanvas *C30 = new TCanvas("C30","A Canvas",10,10,800,600);
   TCanvas *C31 = new TCanvas("C31","A Canvas",10,10,800,600);
   TCanvas *C32 = new TCanvas("C32","A Canvas",10,10,800,600);
   TCanvas *C33 = new TCanvas("C33","A Canvas",10,10,800,600);



   DTDecayTree dt(DTChain);
   MCDecayTree mc(MCChain);

   //Double_t MCBp_M, MCchi_c_M, DTBp_M, DTchi_c_M;
   //MCChain->SetBranchAddress("Bp_M", &MCBp_M);
   //MCChain->SetBranchAddress("chi_c_M", &MCchi_c_M);
   //DTChain->SetBranchAddress("Bp_M", &DTBp_M);
   //DTChain->SetBranchAddress("chi_c_M", &DTchi_c_M);


   for (Long64_t i=0; i < DTChain->GetEntries() ; i++){
	   dt.GetEntry(i);
	   Double_t DT_DM = dt.Bp_M - dt.chi_c_M + 3510;
	   DTh->Fill(DT_DM);
	   //cut candidates
	   h1d->Fill(dt.Bp_ENDVERTEX_CHI2);
	   h2d->Fill(dt.Bp_IPCHI2_OWNPV);
	   h3d->Fill(dt.Bp_FDS);
	   h4d->Fill(dt.Bp_DIRA);
	   h5d->Fill(dt.gamma_CL);
	   h6d->Fill(dt.muplus_IPCHI2_OWNPV);
	   h7d->Fill(dt.muminus_IPCHI2_OWNPV);
	   h8d->Fill(dt.Jpsi_ENDVERTEX_CHI2);
	   h9d->Fill(dt.muplus_ProbNNghost);
	   h10d->Fill(dt.muminus_ProbNNghost);
	   h11d->Fill(dt.muplus_ProbNNmu);
	   h12d->Fill(dt.muminus_ProbNNmu);
	   h13d->Fill(dt.muplus_PT);
	   h14d->Fill(dt.muminus_PT);
	   h15d->Fill(dt.kaonp1_P);
	   h16d->Fill(dt.kaonp2_P);
	   h17d->Fill(dt.kaonm_P);
	   h18d->Fill(dt.kaonp1_PT);
	   h19d->Fill(dt.kaonp2_PT);
	   h20d->Fill(dt.kaonm_PT);
	   h21d->Fill(dt.kaonp1_IPCHI2_OWNPV);
	   h22d->Fill(dt.kaonp2_IPCHI2_OWNPV);
	   h23d->Fill(dt.kaonm_IPCHI2_OWNPV);
	   h24d->Fill(dt.kaonp1_TRACK_CHI2NDOF);
	   h25d->Fill(dt.kaonp2_TRACK_CHI2NDOF);
	   h26d->Fill(dt.kaonm_TRACK_CHI2NDOF);
	   h27d->Fill(dt.kaonp1_hasRich);
	   h28d->Fill(dt.kaonp2_hasRich);
	   h29d->Fill(dt.kaonm_hasRich);
	   h30d->Fill(dt.kaonp1_TRACK_GhostProb);
	   h31d->Fill(dt.kaonp2_TRACK_GhostProb);
	   h32d->Fill(dt.kaonm_TRACK_GhostProb);
	   h33d->Fill(dt.kaonp1_ProbNNk);
	}
	cout << "50%% complete" << endl;
   for (Long64_t i=0; i< MCChain->GetEntries(); i++){
	   mc.GetEntry(i);
   	   //***truthid cut begins here***
   	   //truthid cut 
	   if (!((abs(mc.Bp_TRUEID)==521) && ((abs(mc.chi_c_TRUEID)==20443)||(abs(mc.chi_c_TRUEID)==100445)) && (abs(mc.Jpsi_TRUEID)==443) && (abs(mc.muplus_TRUEID)==13) && (abs(mc.muminus_TRUEID)==13) && (mc.gamma_TRUEID==22) && (abs(mc.kaonp1_TRUEID)==321) && (abs(mc.kaonp2_TRUEID)==211) && (abs(mc.kaonm_TRUEID)==211))) continue;
	   //motherid cut
   	   if (!( (abs(mc.chi_c_MC_MOTHER_ID)==521) && ((abs(mc.Jpsi_MC_MOTHER_ID)==20443) ||(abs(mc.Jpsi_MC_MOTHER_ID)==100445)) && (abs(mc.muplus_MC_MOTHER_ID)==443) && (abs(mc.muminus_MC_MOTHER_ID)==443) && ((mc.gamma_MC_MOTHER_ID==20443)||(mc.gamma_MC_MOTHER_ID==100445)) && (mc.kaonp1_MC_MOTHER_ID==521) && (mc.kaonp2_MC_MOTHER_ID==521) && (mc.kaonm_MC_MOTHER_ID==521))) continue;
	   //gdmotherid cut
   	   if (!( (abs(mc.Jpsi_MC_GD_MOTHER_ID)==521) && ((abs(mc.muplus_MC_GD_MOTHER_ID)==20443)||(abs(mc.muplus_MC_GD_MOTHER_ID)==100445)) && ((abs(mc.muminus_MC_GD_MOTHER_ID)==20443)||(abs(mc.muminus_MC_GD_MOTHER_ID)==100445)) && (mc.gamma_MC_GD_MOTHER_ID==521))) continue;
	   //gdgdmotherid cut
   	   if (!( (abs(mc.muplus_MC_GD_GD_MOTHER_ID)==521) && (abs(mc.muminus_MC_GD_GD_MOTHER_ID)==521))) continue;
	   
	   //***truthid cut ends here***
	   Double_t MC_DM = mc.Bp_M - mc.chi_c_M + 3510;
   	   MCh->Fill(MC_DM);	  
	   //cut candidates
	   h1m->Fill(mc.Bp_ENDVERTEX_CHI2);
	   h2m->Fill(mc.Bp_IPCHI2_OWNPV);
	   h3m->Fill(mc.Bp_FDS);
	   h4m->Fill(mc.Bp_DIRA);
	   h5m->Fill(mc.gamma_CL);
	   h6m->Fill(mc.muplus_IPCHI2_OWNPV);
	   h7m->Fill(mc.muminus_IPCHI2_OWNPV);
	   h8m->Fill(mc.Jpsi_ENDVERTEX_CHI2);
	   h9m->Fill(mc.muplus_ProbNNghost);
	   h10m->Fill(mc.muminus_ProbNNghost);
	   h11m->Fill(mc.muplus_ProbNNmu);
	   h12m->Fill(mc.muminus_ProbNNmu);
	   h13m->Fill(mc.muplus_PT);
	   h14m->Fill(mc.muminus_PT);
	   h15m->Fill(mc.kaonp1_P);
	   h16m->Fill(mc.kaonp2_P);
	   h17m->Fill(mc.kaonm_P);
	   h18m->Fill(mc.kaonp1_PT);
	   h19m->Fill(mc.kaonp2_PT);
	   h20m->Fill(mc.kaonm_PT);
	   h21m->Fill(mc.kaonp1_IPCHI2_OWNPV);
	   h22m->Fill(mc.kaonp2_IPCHI2_OWNPV);
	   h23m->Fill(mc.kaonm_IPCHI2_OWNPV);
	   h24m->Fill(mc.kaonp1_TRACK_CHI2NDOF);
	   h25m->Fill(mc.kaonp2_TRACK_CHI2NDOF);
	   h26m->Fill(mc.kaonm_TRACK_CHI2NDOF);
	   h27m->Fill(mc.kaonp1_hasRich);
	   h28m->Fill(mc.kaonp2_hasRich);
	   h29m->Fill(mc.kaonm_hasRich);
	   h30m->Fill(mc.kaonp1_TRACK_GhostProb);
	   h31m->Fill(mc.kaonp2_TRACK_GhostProb);
	   h32m->Fill(mc.kaonm_TRACK_GhostProb);
	   h33m->Fill(mc.kaonp1_ProbNNk);
   }
   MCh->Scale(1./MCh->Integral());
   DTh->Scale(1./DTh->Integral());
   //cut candidates
   h1d->Scale(1./h1d->Integral());
   h1m->Scale(1./h1m->Integral());
   h2d->Scale(1./h2d->Integral());
   h2m->Scale(1./h2m->Integral());
   h3d->Scale(1./h3d->Integral());
   h3m->Scale(1./h3m->Integral());
   h4d->Scale(1./h4d->Integral());
   h4m->Scale(1./h4m->Integral());
   h5d->Scale(1./h5d->Integral());
   h5m->Scale(1./h5m->Integral());
   h6d->Scale(1./h6d->Integral());
   h6m->Scale(1./h6m->Integral());
   h7d->Scale(1./h7d->Integral());
   h7m->Scale(1./h7m->Integral());
   h8d->Scale(1./h8d->Integral());
   h8m->Scale(1./h8m->Integral());
   h9d->Scale(1./h9d->Integral());
   h9m->Scale(1./h9m->Integral());
   h10d->Scale(1./h10d->Integral());
   h10m->Scale(1./h10m->Integral());
   h11d->Scale(1./h11d->Integral());
   h11m->Scale(1./h11m->Integral());
   h12d->Scale(1./h12d->Integral());
   h12m->Scale(1./h12m->Integral());
   h13d->Scale(1./h13d->Integral());
   h13m->Scale(1./h13m->Integral());
   h14d->Scale(1./h14d->Integral());
   h14m->Scale(1./h14m->Integral());
   h15d->Scale(1./h15d->Integral());
   h15m->Scale(1./h15m->Integral());
   h16d->Scale(1./h16d->Integral());
   h16m->Scale(1./h16m->Integral());
   h17d->Scale(1./h17d->Integral());
   h17m->Scale(1./h17m->Integral());
   h18d->Scale(1./h18d->Integral());
   h18m->Scale(1./h18m->Integral());
   h19d->Scale(1./h19d->Integral());
   h19m->Scale(1./h19m->Integral());
   h20d->Scale(1./h20d->Integral());
   h20m->Scale(1./h20m->Integral());
   h21d->Scale(1./h21d->Integral());
   h21m->Scale(1./h21m->Integral());
   h22d->Scale(1./h22d->Integral());
   h22m->Scale(1./h22m->Integral());
   h23d->Scale(1./h23d->Integral());
   h23m->Scale(1./h23m->Integral());
   h24d->Scale(1./h24d->Integral());
   h24m->Scale(1./h24m->Integral());
   h25d->Scale(1./h25d->Integral());
   h25m->Scale(1./h25m->Integral());
   h26d->Scale(1./h26d->Integral());
   h26m->Scale(1./h26m->Integral());
   h27d->Scale(1./h27d->Integral());
   h27m->Scale(1./h27m->Integral());
   h28d->Scale(1./h28d->Integral());
   h28m->Scale(1./h28m->Integral());
   h29d->Scale(1./h29d->Integral());
   h29m->Scale(1./h29m->Integral());
   h30d->Scale(1./h30d->Integral());
   h30m->Scale(1./h30m->Integral());
   h31d->Scale(1./h31d->Integral());
   h31m->Scale(1./h31m->Integral());
   h32d->Scale(1./h32d->Integral());
   h32m->Scale(1./h32m->Integral());
   h33d->Scale(1./h33d->Integral());
   h33m->Scale(1./h33m->Integral());

   C0->cd();
   MCh->Draw();
   DTh->Draw("sames");
   MCh->SetLineColor(1);
   DTh->SetLineColor(2);
   C0->SaveAs("0_DM.pdf");

   //draw cut candidates
   C1->cd();
   h1d->Draw();
   h1m->Draw("sames");
   h1m->SetLineColor(1);
   h1d->SetLineColor(2);
   C1->SaveAs("1_Bp_ENDVERTEX_CHI2.pdf");

   C2->cd();
   h2d->Draw();
   h2m->Draw("sames");
   h2m->SetLineColor(1);
   h2d->SetLineColor(2);
   C2->SaveAs("2_Bp_IPCHI2_OWNPV.pdf");

   C3->cd();
   h3d->Draw();
   h3m->Draw("sames");
   h3m->SetLineColor(1);
   h3d->SetLineColor(2);
   C3->SaveAs("3_Bp_FDS.pdf");

   C4->cd();
   h4d->Draw();
   h4m->Draw("sames");
   h4m->SetLineColor(1);
   h4d->SetLineColor(2);
   C4->SaveAs("4_Bp_DIRA.pdf");

   C5->cd();
   h5d->Draw();
   h5m->Draw("sames");
   h5m->SetLineColor(1);
   h5d->SetLineColor(2);
   C5->SaveAs("5_gamma_CL.pdf");

   C6->cd();
   h6d->Draw();
   h6m->Draw("sames");
   h6m->SetLineColor(1);
   h6d->SetLineColor(2);
   C6->SaveAs("6_muplus_IPCHI2_OWNPV.pdf");

   C7->cd();
   h7d->Draw();
   h7m->Draw("sames");
   h7m->SetLineColor(1);
   h7d->SetLineColor(2);
   C7->SaveAs("7_muminus_IPCHI2_OWNPV.pdf");

   C8->cd();
   h8d->Draw();
   h8m->Draw("sames");
   h8m->SetLineColor(1);
   h8d->SetLineColor(2);
   C8->SaveAs("8_Jpsi_ENDVERTEX_CHI2.pdf");

   C9->cd();
   h9d->Draw();
   h9m->Draw("sames");
   h9m->SetLineColor(1);
   h9d->SetLineColor(2);
   C9->SaveAs("9_muplus_ProbNNghost.pdf");

   C10->cd();
   h10d->Draw();
   h10m->Draw("sames");
   h10m->SetLineColor(1);
   h10d->SetLineColor(2);
   C10->SaveAs("10_muminus_ProbNNghost.pdf");

   C11->cd();
   h11d->Draw();
   h11m->Draw("sames");
   h11m->SetLineColor(1);
   h11d->SetLineColor(2);
   C11->SaveAs("11_muplus_ProbNNmu.pdf");

   C12->cd();
   h12d->Draw();
   h12m->Draw("sames");
   h12m->SetLineColor(1);
   h12d->SetLineColor(2);
   C12->SaveAs("12_muminus_ProbNNmu.pdf");

   C13->cd();
   h13d->Draw();
   h13m->Draw("sames");
   h13m->SetLineColor(1);
   h13d->SetLineColor(2);
   C13->SaveAs("13_muplus_PT.pdf");

   C14->cd();
   h14d->Draw();
   h14m->Draw("sames");
   h14m->SetLineColor(1);
   h14d->SetLineColor(2);
   C14->SaveAs("14_muminus_PT.pdf");

   C15->cd();
   h15d->Draw();
   h15m->Draw("sames");
   h15m->SetLineColor(1);
   h15d->SetLineColor(2);
   C15->SaveAs("15_kaonp1_P.pdf");

   C16->cd();
   h16d->Draw();
   h16m->Draw("sames");
   h16m->SetLineColor(1);
   h16d->SetLineColor(2);
   C16->SaveAs("16_kaonp2_P.pdf");

   C17->cd();
   h17d->Draw();
   h17m->Draw("sames");
   h17m->SetLineColor(1);
   h17d->SetLineColor(2);
   C17->SaveAs("17_kaonm_P.pdf");

   C18->cd();
   h18d->Draw();
   h18m->Draw("sames");
   h18m->SetLineColor(1);
   h18d->SetLineColor(2);
   C18->SaveAs("18_kaonp1_PT.pdf");

   C19->cd();
   h19d->Draw();
   h19m->Draw("sames");
   h19m->SetLineColor(1);
   h19d->SetLineColor(2);
   C19->SaveAs("19_kaonp2_PT.pdf");

   C20->cd();
   h20d->Draw();
   h20m->Draw("sames");
   h20m->SetLineColor(1);
   h20d->SetLineColor(2);
   C20->SaveAs("20_kaonm_PT.pdf");

   C21->cd();
   h21d->Draw();
   h21m->Draw("sames");
   h21m->SetLineColor(1);
   h21d->SetLineColor(2);
   C21->SaveAs("21_kaonp1_IPCHI2_OWNPV.pdf");

   C22->cd();
   h22d->Draw();
   h22m->Draw("sames");
   h22m->SetLineColor(1);
   h22d->SetLineColor(2);
   C22->SaveAs("22_kaonp2_IPCHI2_OWNPV.pdf");

   C23->cd();
   h23d->Draw();
   h23m->Draw("sames");
   h23m->SetLineColor(1);
   h23d->SetLineColor(2);
   C23->SaveAs("23_kaonm_IPCHI2_OWNPV.pdf");

   C24->cd();
   h24d->Draw();
   h24m->Draw("sames");
   h24m->SetLineColor(1);
   h24d->SetLineColor(2);
   C24->SaveAs("24_kaonp1_TRACK_CHI2NDOF.pdf");

   C25->cd();
   h25d->Draw();
   h25m->Draw("sames");
   h25m->SetLineColor(1);
   h25d->SetLineColor(2);
   C25->SaveAs("25_kaonp2_TRACK_CHI2NDOF.pdf");

   C26->cd();
   h26d->Draw();
   h26m->Draw("sames");
   h26m->SetLineColor(1);
   h26d->SetLineColor(2);
   C26->SaveAs("26_kaonm_TRACK_CHI2NDOF.pdf");

   C27->cd();
   h27d->Draw();
   h27m->Draw("sames");
   h27m->SetLineColor(1);
   h27d->SetLineColor(2);
   C27->SaveAs("27_kaonp1_hasRich.pdf");

   C28->cd();
   h28d->Draw();
   h28m->Draw("sames");
   h28m->SetLineColor(1);
   h28d->SetLineColor(2);
   C28->SaveAs("28_kaonp2_hasRich.pdf");

   C29->cd();
   h29d->Draw();
   h29m->Draw("sames");
   h29m->SetLineColor(1);
   h29d->SetLineColor(2);
   C29->SaveAs("29_kaonm_hasRich.pdf");

   C30->cd();
   h30d->Draw();
   h30m->Draw("sames");
   h30m->SetLineColor(1);
   h30d->SetLineColor(2);
   C30->SaveAs("30_kaonp1_TRACK_GhostProb.pdf");

   C31->cd();
   h31d->Draw();
   h31m->Draw("sames");
   h31m->SetLineColor(1);
   h31d->SetLineColor(2);
   C31->SaveAs("31_kaonp2_TRACK_GhostProb.pdf");

   C32->cd();
   h32d->Draw();
   h32m->Draw("sames");
   h32m->SetLineColor(1);
   h32d->SetLineColor(2);
   C32->SaveAs("32_kaonm_TRACK_GhostProb.pdf");

   C33->cd();
   h33d->Draw();
   h33m->Draw("sames");
   h33m->SetLineColor(1);
   h33d->SetLineColor(2);
   C33->SaveAs("33_kaonp1_ProbNNk.pdf");


}

